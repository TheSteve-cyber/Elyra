# ✦ Elyra — Site + Backend

Estrutura de dois projetos:
- `elyra-site/` → Frontend (GitHub Pages)
- `elyra-backend/` → Backend Node.js (Render.com)

---

## 📁 Estrutura

```
elyra-site/
├── index.html
├── style.css
├── chat.js
├── roblox.js
└── assets/
    └── elyra.jpg

elyra-backend/
├── server.js
├── package.json
├── .env.example
└── .gitignore
```

---

## 🚀 Deploy — Passo a Passo

### 1. Backend no Render.com

1. Crie uma conta gratuita em **render.com**
2. Clique em **New → Web Service**
3. Conecte ao GitHub e suba a pasta `elyra-backend` como repositório separado
4. Configure assim:
   - **Runtime:** Node
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
5. Em **Environment Variables**, adicione:
   - `GROQ_API_KEY` = sua chave da Groq (obtenha em console.groq.com)
6. Clique em **Deploy**
7. Anote a URL do seu serviço (ex: `https://elyra-backend.onrender.com`)

---

### 2. Atualizar a URL no Frontend

Abra o arquivo `elyra-site/chat.js` e troque na linha 7:

```js
// Antes:
const BACKEND_URL = 'https://elyra-backend.onrender.com'

// Depois (coloque a URL real do seu Render):
const BACKEND_URL = 'https://SEU-SERVICO.onrender.com'
```

---

### 3. Frontend no GitHub Pages

1. Crie uma conta no **github.com** (se não tiver)
2. Crie um novo repositório chamado `elyra-site` (público)
3. Faça upload de todos os arquivos da pasta `elyra-site/` (incluindo a pasta `assets/`)
4. Vá em **Settings → Pages**
5. Em **Source**, selecione `main` branch e pasta `/root`
6. Clique em **Save**
7. Seu site estará em: `https://seuusuario.github.io/elyra-site`

---

## 🔑 API Key Groq

- Acesse: https://console.groq.com
- Vá em **API Keys → Create API Key**
- Copie a chave (começa com `gsk_`)
- Cole no Render em Environment Variables

---

## ✅ Pronto!

Seu site estará online com:
- Landing page completa com a imagem da Elyra
- Chat com IA (Llama 3.3 70B)
- Busca de perfil Roblox com `!roblox <usuário>`
- API key protegida no backend
