import express from 'express'
import cors from 'cors'
import dotenv from 'dotenv'
import Groq from 'groq-sdk'

dotenv.config()

const app = express()
const groq = new Groq({ apiKey: process.env.GROQ_API_KEY })

app.use(cors())
app.use(express.json())

// ── POST /chat ──
app.post('/chat', async (req, res) => {
  try {
    const { messages } = req.body

    if (!messages || !Array.isArray(messages)) {
      return res.status(400).json({ error: 'messages array required' })
    }

    const completion = await groq.chat.completions.create({
      model: 'llama-3.3-70b-versatile',
      messages: [
        {
          role: 'system',
          content: 'Você é Elyra, uma assistente inteligente, mística e elegante que responde em português. Seja concisa, perspicaz e mantenha sua personalidade única. Não use markdown excessivo nas respostas.'
        },
        ...messages
      ],
      max_tokens: 1024,
      temperature: 0.8
    })

    res.json({ reply: completion.choices[0].message.content })
  } catch (err) {
    console.error('Groq error:', err)
    res.status(500).json({ error: 'Erro interno. Tente novamente.' })
  }
})

// ── GET /health ──
app.get('/health', (_, res) => res.json({ status: 'ok', name: 'Elyra Backend' }))

const PORT = process.env.PORT || 3000
app.listen(PORT, () => console.log(`✦ Elyra backend rodando na porta ${PORT}`))
